
from setuptools import setup

from urllib.request import ProxyHandler, build_opener, install_opener
proxy_handle = ProxyHandler({'http': 'web-proxy.tencent.com:8080',
                             'https': 'web-proxy.tencent.com:8080'})
opener = build_opener(proxy_handle)
install_opener(opener)
setup(
    name='qcloud-python-sts',
    version='1.3.3',
    description='this is sts for python on v3',
    url='https://github.com/tencentyun/qcloud-cos-sts-sdk',
    author='qcloudterminal',
    author_email='qcloudterminal@gmail.com',
    license='MIT',
    packages=['sts'],
    install_requires=['requests']
)
